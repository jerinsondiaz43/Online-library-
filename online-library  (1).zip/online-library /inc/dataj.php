<?php
$catalog = [];
//Books
$catalog[101] = [
	"title" => "percy jackson",
	"img" => "img/media/percy jackson.jpg",
    "genre" => "fiction",
    "format" => "paperback",
    "year" => 2005,
    "category" => "Books",
    "authors" => [
        "Rick Riordan"
    ],
    "publisher" => "Disney,by Julie Foudy",
    "isbn" => '9781368003384 '
];
$catalog[102] = [
    "title" => "twilight",
    "img" => "img/media/book-twilight.jpg",
    "genre" => "Fiction",
    "format" => "hardcover",
    "year" => 2005,
    "category" => "Books",
    "authors" => [
        " Stephenie Meyer"
    ],
    "publisher" => "Little, Brown and Company ",
    "isbn" => '9780743273565'
];
$catalog[103] = [
    "title" => "metamorphosis",
    "img" => "img/media/kafka-metamorphosis.jpg",
    "genre" => "Gothic Fiction",
    "format" => "Paperback",
    "year" => 1915,
    "category" => "Books",
    "authors" => [
        " Franz Kafka"
    ],
    "publisher" => "German: Die Verwandlung",
    "isbn" => '978-3-89896-519-4.'
];
$catalog[104] = [
    "title" => "narnia ",
    "img" => "img/media/Narnia.jpg",
    "genre" => "Horror",
    "format" => "Paperback",
    "year" => 1950,
    "category" => "Books",
    "authors" => [
        " ‎C. S. Lewis"
    ],
    "publisher" => "Geoffrey Bles",
    "isbn" => '9781935251682'
];
//Movies
$catalog[201] = [
    "title" => "Transpotated 3",
    "img" => "img/media/Transpotated 3.jpg",
    "genre" => "Action",
    "format" => "DVD/Streaming",
    "year" => 2008,
    "category" => "Movies",
    "director" => "Olivier Megaton",
    "writers" => [
        "Luc Besson",
        "Robert Mark kamen"
    ],
    "stars" => [
        "Jason statham",
        "Natalya Rudakova",
        "Robert Knepper",
    ]
];
$catalog[202] = [
    "title" => "John Wick",
    "img" => "img/media/John Wick.jpg",
    "genre" => "action,Fiction",
    "format" => "DVD/Streaming",
    "year" => 2019,
    "category" => "Movies",
    "director" => "Chad Stahelski",
    "writers" => [
        "Derek kolstad",
				"Shay Hatten"
        "Marc Abrmas"
        "Chirs Collins"
    ],
    "stars" => [
			"Keanu Reeves",
			"Halle Berry",
			"Ian Mcshane",
        "laurence fishburne",
        "Asia kate Dillon",
    ]
];
$catalog[203] = [
    "title" => "Dragon ball super",
    "img" => "img/media/Dragon ball super.jpg",
    "genre" => "Action,fiction,animated",
    "format" => "DVD/streaming",
    "year" => 2019,
    "category" => "Movies",
    "director" => "Tatsuya Nagamine",
    "writers" => [
        "Akira Toriyama",
        "Lionel Wigram",
    ],
    "stars" => [
			"Masako=goku",
			"Ryo Horikawa=vegeta",
			"Vic Mignogna",
    ]
];
$catalog[204] = [
    "title" => "Avengers",
		"img" => "img/media/avengers.jpg",
	  "genre" => "Drama, Science Fiction",
	  "format" => "DVD/Streaming",
	  "year" => 2019,
	  "category" => "Movies",
	  "director" => "Russos brohters",
	  "writers" => [
	      "Stephen Mcfeely",
          "christopher Markus",   
	  ],
	  "stars" => [
	      "Robert Downey jr.",
	      "Chris Evans",
	      "chris Hemworth",
          "Scarlett johansson",
          "Jeremy Renner",
          "Brie Larson",
	  ]
	];
//Music
$catalog[301] = [
	"title" => "el Farzante",
	"img" => "img/media/romeosantos.jpg",
	"genre" => "Prison Jazz, Experimental Rock",
	"format" => "CD,online",
	"year" => 2018,
	"category" => "Music",
	"artist" => "remeo santo,ozuna"
];

$catalog[302] = [
	"title" => "River",
	"img" => "img/media/emimem.jpg",
	"genre" => "rap Hip-Hop",
	"format" => "Streaming Services",
	"year" => 2017,
	"category" => "Music",
	"artist" => "emimem,,Ed sheeran"
];
$catalog[303] = [
	"title" => "Si se da",
	"img" => "img/media/Si se da.jpg",
	"genre" => "reggeton",
	"format" => "CD, Streaming Services",
	"year" => 2019,
	"category" => "Music",
	"artist" => "Myke Towers, Farruko, Arcangel, Sech & Ziono",
];
$catalog[304] = [
	"title" => "landscape",
	"img" => "img/media/nocopyrithmusic.jpg",
	"genre" => "Funk, Electronic",
	"format" => "youtube, Streaming Services",
	"year" => 2018,
	"category" => "Music",
	"artist" => "jerico"
];
?>
